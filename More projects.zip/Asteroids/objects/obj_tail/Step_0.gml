
if(instance_exists(obj_ship)){
    var ship=obj_ship;
    
    
    var rad=ship.image_angle*pi/180;
 
    var hipotenusa=ship.sprite_width/2;
    var cy=hipotenusa*sin(rad);
    var cx=hipotenusa*cos(rad);
 
    x=ship.x -cx;
    y=ship.y +cy;
    image_angle=ship.image_angle;
    
}else{

    instance_destroy();
}

