bullet=instance_create(x,y,obj_bullet);
bullet.speed=15;
bullet.direction=image_angle;
bullet.image_angle=image_angle;

