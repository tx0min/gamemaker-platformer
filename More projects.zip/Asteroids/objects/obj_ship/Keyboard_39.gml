image_angle-=5;
if(image_angle<=0) image_angle=360;


