speed=max(speed - 0.05, 0);

