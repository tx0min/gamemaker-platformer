instance_create(x,y,obj_dead_ship_1);
instance_create(x,y,obj_dead_ship_2);
instance_create(x,y,obj_dead_ship_3);
instance_create(x,y,obj_dead_ship_4);

