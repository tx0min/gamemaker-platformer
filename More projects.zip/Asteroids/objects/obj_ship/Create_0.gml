instance_create(x-(sprite_width/2),y,obj_tail);
image_speed=1/2;
alarm[0] = 240; //evento alarm0 que se llama a los 240 frames




