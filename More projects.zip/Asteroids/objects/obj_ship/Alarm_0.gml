sprite_index=spr_ship;



