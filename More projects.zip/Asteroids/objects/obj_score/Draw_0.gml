draw_set_halign(fa_left);
draw_set_valign(fa_top);

draw_set_color(c_white);
draw_set_font(fnt_small);
var points=scr_zeropad(global.points,8);

draw_text(24,24,string_hash_to_newline("SCORE: "+points));
draw_text(24,48,string_hash_to_newline("LIVES: "+string(global.life)));

