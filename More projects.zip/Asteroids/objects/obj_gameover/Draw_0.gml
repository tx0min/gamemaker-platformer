draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_set_font(fnt_big);
draw_set_color(c_white);
draw_text(room_width/2,room_height/2-40,string_hash_to_newline("Game Over!"));
draw_set_font(fnt_small);

draw_text(room_width/2,room_height/2 , string_hash_to_newline("Score: "+ scr_zeropad(global.points,8)));

draw_text(room_width/2,room_height/2 +40,string_hash_to_newline("Press R to restart"));




