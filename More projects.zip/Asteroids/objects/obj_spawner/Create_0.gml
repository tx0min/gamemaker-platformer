if (!instance_exists(obj_ship)){
     instance_create(room_width/2,room_height/2,obj_ship);
}


