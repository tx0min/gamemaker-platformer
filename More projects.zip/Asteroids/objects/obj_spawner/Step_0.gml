if (instance_number(obj_asteroid)<3){
    for(i=0;i<5;i++)
        instance_create(random(room_width),random(room_height),obj_asteroid);
}


