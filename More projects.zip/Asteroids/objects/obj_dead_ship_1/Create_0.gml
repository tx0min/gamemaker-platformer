speed=1+random(1);
direction=random(360);

