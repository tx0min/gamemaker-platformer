speed=0.5+random(2);
image_speed=0;
image_index=irandom(1);

direction=random(360);



scale=0.3+random(0.5);
image_xscale*=scale;
image_yscale*=scale;

rdirection=1;
if(irandom(1)==1) rdirection=-1;

