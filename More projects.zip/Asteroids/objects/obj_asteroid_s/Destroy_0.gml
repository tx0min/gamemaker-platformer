global.points+=75;
audio_play_sound(snd_explosion,0,0);

