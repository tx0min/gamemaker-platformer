with (other) {
if(sprite_index==spr_ship){
    instance_destroy();
    
    audio_play_sound(snd_explosion,0,0);
    
    if(global.life>1){
        global.life--;
        instance_create(room_width/2,room_height/2,obj_ship);
    }else{
        instance_create(0,0,obj_gameover);
    }
}

}
