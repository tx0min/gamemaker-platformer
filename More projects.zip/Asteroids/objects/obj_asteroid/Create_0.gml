/*while(place_meeting(x,y,obj_ship){
    x=random(room_width);
    y=random(room_height);
}*/

while(distance_to_object(obj_ship)<100){
    x=random(room_width);
    y=random(room_height);
}

speed=0.5+random(2);
image_speed=0;
image_index=irandom(1);

direction=random(360);



scale=0.3+random(0.5);
image_xscale*=scale;
image_yscale*=scale;

rdirection=1;
if(irandom(1)==1) rdirection=-1;

/* */
/*  */
