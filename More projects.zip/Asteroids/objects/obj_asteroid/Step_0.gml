image_angle=image_angle + (rdirection*0.5);

