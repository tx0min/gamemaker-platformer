instance_create(x,y,obj_asteroid_s);
instance_create(x,y,obj_asteroid_s);
global.points+=50;

audio_play_sound(snd_explosion,0,0);


