instance_destroy();

