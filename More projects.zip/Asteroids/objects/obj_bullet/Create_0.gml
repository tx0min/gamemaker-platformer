audio_play_sound(snd_laser,0,0);

