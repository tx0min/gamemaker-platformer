function scr_zeropad(argument0, argument1) {
	score_str = string(floor(argument0)) // string with score

	score_num = argument1; // number of digits

	score_full = string_repeat("0",score_num - string_length(score_str)) + score_str;
	return score_full;



}
