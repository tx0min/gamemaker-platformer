passed=false;
hspeed=-2;


