/// @description Score counter

if(instance_exists(oPlayer)){
    if(x <= oPlayer.x && !passed ){
        global.points++; 
        passed=true;
        audio_play_sound(sndCoin, 1,false);
        
    }
   
}

