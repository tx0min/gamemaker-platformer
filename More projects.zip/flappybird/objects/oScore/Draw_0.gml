if(global.gamestarted){
    draw_set_halign(fa_center);
    draw_set_valign(fa_top);
    var points=lpad(global.points,0);
    
    
    
    //draw_circle_outline(view_wview/2, view_yview+54,30,6, global.maincolor,global.altcolor);
    draw_text_outline(__view_get( e__VW.WView, 0 )/2, __view_get( e__VW.YView, 0 )+24, 1, points, c_white,global.altcolor,fnt_big);
}

