// draw_circle(view_wview/2, view_hview/2,5,0);

draw_set_halign(fa_center);
draw_set_valign(fa_middle);

if(!global.gamestarted){
    draw_text_outline( round(__view_get( e__VW.WView, 0 )/2), round(__view_get( e__VW.HView, 0 )/2),  1, "Press SPACE to start", global.maincolor, global.altcolor, fnt_big);
}

if(global.gameover){
    var points=lpad(global.points,8);
    draw_text_outline( round(__view_get( e__VW.WView, 0 )/2), round(__view_get( e__VW.HView, 0 )/2)-10,  1, "GAME OVER", global.maincolor, global.altcolor, fnt_big);
    draw_text_outline( round(__view_get( e__VW.WView, 0 )/2), round(__view_get( e__VW.HView, 0 )/2)+40,  1, "Press R to restart", c_white, global.altcolor, fnt_small);

}


