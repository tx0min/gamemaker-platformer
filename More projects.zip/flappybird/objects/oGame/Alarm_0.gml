/// @description Pipe line generator

var mingap=round(__view_get( e__VW.HView, 0 )/4);
var maxgap=round(__view_get( e__VW.HView, 0 )/2);

var gap= floor(random_range(mingap,maxgap));
var minheight=100;    

var gapy = round(random_range(minheight,__view_get( e__VW.HView, 0 )-minheight));

var pipew= sprite_get_width(sPipe);
var pipeh= sprite_get_height(sPipe);
var pipeendh= sprite_get_height(sPipeEnding);


//draw upper pipe
var pipespeed=-2;

var ypos1= (gapy - round(gap/2))/2;


var scale1 =  ypos1*2 / pipeh ;
log("UPPER",gap,gapy,ypos1,scale1);

var pipe1=instance_create(__view_get( e__VW.XView, 0 ) + __view_get( e__VW.WView, 0 ) + pipew/2, ypos1, oPipe);   
pipe1.hspeed=pipespeed;
pipe1.passed=false;
pipe1.image_yscale=scale1;

var endpos= gapy - round(gap/2) - round(pipeendh/2);
var pipeend1=instance_create(__view_get( e__VW.XView, 0 ) + __view_get( e__VW.WView, 0 ) + pipew/2, endpos, oPipeEnding);   
pipeend1.hspeed=pipe1.hspeed;





//draw lower pipe
var yini= gapy + round(gap/2);
var ypos2= yini + round((__view_get( e__VW.HView, 0 ) - yini)/2);


var scale2 =  (__view_get( e__VW.HView, 0 )-yini) / pipeh ;
//log("LOWER",gap,gapy,ypos2,scale2);

var pipe2=instance_create(__view_get( e__VW.XView, 0 ) + __view_get( e__VW.WView, 0 ) + pipew/2, ypos2, oPipe);   
pipe2.hspeed=pipespeed;
pipe2.passed = (ypos1>0);
pipe2.image_yscale=scale2;

var endpos2= yini + round(pipeendh/2);
var pipeend2=instance_create(__view_get( e__VW.XView, 0 ) + __view_get( e__VW.WView, 0 ) + pipew/2, endpos2, oPipeEnding);   
pipeend2.hspeed=pipe2.hspeed;



//if( gapy < view_hview-10){
    //draw lower pipe
    
//}

//instance_create(view_xview+view_wview-1, 0, oPipe);

alarm[0]=random_range(pipemininterval,pipemaxinterval);

