//global score
global.points=0;
global.maincolor= make_colour_rgb(212,191,39);
global.altcolor= c_red;
      
global.gamestarted=false;
global.gameover=false;

//Pipe variables
pipemininterval=120;  //1 pipe per 2 second
pipemaxinterval=180;  //1 pipe per 3 second

audio_play_sound(sndMusic, 1,true);



