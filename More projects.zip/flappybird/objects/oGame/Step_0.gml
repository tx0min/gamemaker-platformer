/// @description Keyboard
var kRestart, kExit, kPrev, kNext;

kRestart = keyboard_check_pressed(ord("R"));
kExit    = keyboard_check_pressed(vk_escape);
kSpace    = keyboard_check_pressed(vk_space);
kPrev    = keyboard_check_pressed(ord("X"));
kNext    = keyboard_check_pressed(ord("Z"));
kFS    = keyboard_check_pressed(ord("F"));

if(kFS)
    window_set_fullscreen(!window_get_fullscreen());
if (kRestart)
    game_restart();
if (kExit)
    game_end();

if(kSpace){
    //start game
    
    if(!global.gamestarted){
        global.gamestarted=true;
        //init pipe generation
        alarm[0]=1;
        
        //Create Player
        instance_create(0,0,oPlayer);
        audio_play_sound(sndJump, 1,false);
        with(oPlayer){
            gravity=0.5;
            vspeed=-10;
        }
        

        //parallax scroll
        var i=0; 
        repeat(3){
            __background_set( e__BG.HSpeed, i, -1.2*i );
            i++;
        }

    }else{
        if(instance_exists(oPlayer)){
            with(oPlayer){
                vspeed=-10;
                audio_play_sound(sndJump, 1,false);
            }
        }
            
    }
}    
        
// Iterate through rooms backward
if (kPrev) {
    if (room == room_first)
        room_goto(room_last);
    else
        room_goto_previous();
}

// Iterate through rooms forwards
if (kNext) {
    if (room == room_last)
        room_goto(room_first);
    else
        room_goto_next();
}

