gravity=0;
vspeed=0;
x= round(__view_get( e__VW.WView, 0 )/3);
y= round(__view_get( e__VW.HView, 0 )/2);



