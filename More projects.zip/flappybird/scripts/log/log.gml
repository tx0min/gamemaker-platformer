/// @description log(var1,var2,var3...)
/// @param var1
/// @param var2
/// @param var3...
function log() {
	var r = string(argument[0]), i;
	for (i = 1; i < argument_count; i++) {
	    r += ", " + string(argument[i])
	}
	show_debug_message(r)



}
