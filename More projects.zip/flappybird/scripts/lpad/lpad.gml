/// @description lpad(number,digits)
/// @param number
/// @param digits
function lpad() {

	score_str = string(floor(argument0)) // string with score
	score_num = argument1; // number of digits
	if (argument_count > 2) char=argument[2];
	else char="0";

	score_full = string_repeat(char,score_num - string_length(score_str)) + score_str;
	return score_full;



}
