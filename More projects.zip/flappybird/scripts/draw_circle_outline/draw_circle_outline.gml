/// @description draw_circle_outline(x, y, radius, outlinepixels, bgcolor, outlinecolor);
/// @param x
/// @param  y
/// @param  radius
/// @param  outlinepixels
/// @param  bgcolor
/// @param  outlinecolor
function draw_circle_outline(argument0, argument1, argument2, argument3, argument4, argument5) {

	var color;
	color=draw_get_color();
	draw_set_colour(argument4);

	draw_circle(argument0,argument1,argument2,false);

	draw_set_colour(argument5);
	var i=0;
	repeat(argument3){
	    draw_circle(argument0,argument1,argument2+i,true);
	    i++;
	}

	draw_set_color(color);



}
