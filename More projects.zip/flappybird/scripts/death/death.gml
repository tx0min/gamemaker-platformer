/// @description death()
function death() {

   
	   effect_create_above(ef_explosion, x, y, 1, global.maincolor);
	   audio_play_sound(sndDeath, 1,false);
	   instance_destroy();
	     global.gameover=true;        
   
	//game_restart();



}
