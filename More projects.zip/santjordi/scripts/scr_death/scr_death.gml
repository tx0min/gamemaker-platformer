function scr_death() {

	scr_log(global.checkpoint,global.checkpointx,global.checkpointy);
	room_restart();




}
