var minimo=1;
var maximo=1.2;



image_xscale += (dir*0.01);
image_yscale += (dir*0.01);

if( image_xscale < minimo || image_xscale > maximo){
   dir*=-1;
}

