dir=1;

