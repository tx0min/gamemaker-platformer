jumpspeed=jumpspeed_normal;
movespeed = movespeed_normal;
invencible=false;
if(instance_exists(obj_player_star)) 
with(obj_player_star) instance_destroy();

