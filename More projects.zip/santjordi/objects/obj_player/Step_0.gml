if(global.pause) exit;

///Get the player's input
key_right = keyboard_check(vk_right); //ord("D") tecla D
key_left = -keyboard_check(vk_left);
key_jump = keyboard_check_pressed(vk_space); 
key_jump_held = keyboard_check(vk_space);
key_down = keyboard_check(vk_down);

//react to inputs
move= key_left + key_right;

//incremento la velocidad segun la aceleracion
hsp += move * acceleration;


//velocidad maxima
if(abs(hsp) > movespeed) hsp = move * movespeed;


//controla la friccion
if(move==0){
    dir=0;
    if(hsp<0){
        if(hsp+deceleration>0) hsp=0;
        else hsp+=deceleration;
    }else if(hsp>0){
         if(hsp-deceleration<0) hsp=0;
        else hsp-=deceleration;
    }

}



//gravedad
if (vsp < 10) vsp += grav;



//salto individual
//si estamos justo encima del suelo y pulsan saltamos
/*if (place_meeting(x,y+1,obj_wall))
{
    if(key_jump) vsp = -jumpspeed;
}
*/


//JUMPS
//salto multiple
//si estoy en el suelo el numero de saltos permitidos sube al maximo
if (place_meeting(x,y+1,obj_wall))
{
    jumps=jumpsmax;
}


//si pulsan salto y me quedan saltos
if(key_jump && jumps>0){
    jumps-=1;
    vsp = -jumpspeed;
    audio_play_sound(snd_jump,0,0);
}

//wall jump
if(key_jump && (place_meeting(x+walljumppx,y,obj_wall) || place_meeting(x-walljumppx,y,obj_wall))){
    vsp = -jumpspeed;    
}

//si no mantienen la tecla baja la velocidad
if(vsp<0 && !key_jump_held){
    vsp = max(vsp, -minjumpspeed);
}


//moving platforms
var hsp_final= hsp + hsp_carry;
hsp_carry=0;




//Horizontal collision
if(place_meeting(x+hsp_final,y,obj_wall)){
    yplus = 0;
    while(place_meeting(x+hsp_final,y-yplus,obj_wall) && yplus <= abs(1*hsp_final)){
        yplus+=1;
    }
    
    if(place_meeting(x+hsp_final,y-yplus,obj_wall))
    {
        while(!place_meeting(x+sign(hsp_final),y,obj_wall)){ 
            //sign devuelve 1 o -1
            x+=sign(hsp_final);
        }
        hsp_final=0;
        hsp=0;
    }else{
        y-=yplus;
    }
}
x += hsp_final;

//Vertical collision
if(place_meeting(x,y+vsp,obj_wall)){
    while(!place_meeting(x,y+sign(vsp),obj_wall)){ 
        y+=sign(vsp);
    }
    vsp=0;

}
y += vsp;




//Animations
if(move!=0)  image_xscale = move;

//si estamos en el suelo
if(place_meeting(x,y+1,obj_wall)){   
    if(hsp!=0){
        sprite_index=spr_player_walk;
    }else{
        sprite_index=spr_player;
    }
} else {
    if(vsp<0) sprite_index=spr_player_jump;
    else sprite_index=spr_player_fall;
}   



/*

if(invencible){
    image_yscale=1;
    image_xscale=1;
}else{
    image_yscale=0.6;
     image_xscale=0.6;
}
*/




//check falling
if(y - sprite_height/2 > __view_get( e__VW.YView, 0 )+ __view_get( e__VW.HView, 0 )){
    scr_death();
}



/* */
/*  */
