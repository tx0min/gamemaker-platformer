/// @description Initialize Variables
grav = 0.2; //gravedad
hsp = 0; //horizontal speed
hsp_carry=0; //carried h speed
vsp = 0; //vertical speed

acceleration=0.2;
deceleration=0.2;


invencible=false;
jumps=0;
jumpsmax=2;
walljumppx=1;


jumpspeed_normal=8;
jumpspeed_powerup=10;


movespeed_normal=5;
movespeed_powerup=5;


jumpspeed = jumpspeed_normal;
movespeed = movespeed_normal;

minjumpspeed=jumpspeed/2;


if(global.checkpoint!=noone){
    x=global.checkpointx;    
    y=global.checkpointy;
}

key_down=0;

