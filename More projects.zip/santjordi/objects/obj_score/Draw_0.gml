
draw_set_halign(fa_left);
draw_set_valign(fa_top);



var points=scr_zeropad(global.points,8);



draw_text_outline(__view_get( e__VW.XView, 0 )+24,__view_get( e__VW.YView, 0 )+24, 1, "SCORE: "+points, c_white,c_black,fnt_small);

//draw_text(view_xview+24,view_yview+24,"SCORE: "+points);
//draw_text(24,48,"LIVES: "+string(global.life));




