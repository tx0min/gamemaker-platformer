audio_play_sound(snd_powerup,0,0);

