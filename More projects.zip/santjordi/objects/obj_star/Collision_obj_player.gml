with(obj_player){
    jumpspeed=jumpspeed_powerup;
    movespeed = movespeed_powerup;
    alarm[0]=600;
    invencible=true;
    instance_create(x,y,obj_player_star);
}



global.points+=100;

//destruye la estrella
instance_destroy();

