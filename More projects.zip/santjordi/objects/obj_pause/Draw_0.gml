var left=__view_get( e__VW.XView, 0 );
var top=__view_get( e__VW.YView, 0 );
var width=__view_get( e__VW.WView, 0 );
var height=__view_get( e__VW.HView, 0 );



if(global.pause){
    
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_black);
    draw_set_alpha(0.5);
    draw_rectangle(left,top,left+width,top+height,0);

    
    draw_set_alpha(1);
    draw_set_halign(fa_center);


    draw_text_outline(left+(width/2),top+(height/2), 3, "Game Paused", c_white,c_black,fnt_menu);

    draw_text_outline(left+(width/2),top+(height/2)+80, 1, "Press F to toggle fullscreen", c_white,c_black,fnt_small);
    draw_text_outline(left+(width/2),top+(height/2)+110, 1, "Press Q to quit game", c_white,c_black,fnt_small);
    draw_text_outline(left+(width/2),top+(height/2)+140, 1, "Press R to restart", c_white,c_black,fnt_small);


    
}

