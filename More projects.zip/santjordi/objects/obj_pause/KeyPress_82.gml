game_restart();

