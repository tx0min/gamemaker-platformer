global.pause=0;


