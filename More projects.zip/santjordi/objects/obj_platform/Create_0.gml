action_inherited();
sprite_index=-1; //no sprite

