if(instance_exists(obj_player)){

    //if player under of the platform or clicks down
    if ((round( obj_player.y + (obj_player.sprite_height/2)) > y) || obj_player.key_down){
         mask_index=-1; //disable collision
    }else{
         mask_index=spr_platform;
    }
    
  
}

