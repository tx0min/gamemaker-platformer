

var xx=obj_player.x;
var yy= obj_player.y - obj_player.sprite_height/2 -30;

draw_sprite_stretched(spr_star, 0 , xx-10 , yy , 32, 32 );


var time=ceil(obj_player.alarm[0]/100);


draw_text_outline(xx,yy-40, 1, time, c_yellow,c_red,fnt_small);


