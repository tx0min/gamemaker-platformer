//Scroll

__background_set( e__BG.X, 1, __view_get( e__VW.XView, 0 )/2 );
__background_set( e__BG.X, 2, __view_get( e__VW.XView, 0 )/4 );

