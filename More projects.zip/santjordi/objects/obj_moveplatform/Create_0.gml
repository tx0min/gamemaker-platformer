//Initialize variables

sprite_index=-1;

dir=-1;
movespeed=3;
hsp=0;



