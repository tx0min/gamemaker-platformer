if(global.pause) exit;


mask_index=spr_platform;

hsp = dir * movespeed;

//Horizontal collision
if(place_meeting(x+hsp,y,obj_wall)){
    while(!place_meeting(x+sign(hsp),y,obj_wall)){ 
        //sign devuelve 1 o -1
        x+=sign(hsp);
    }
    hsp=0;
    dir*=-1;
}
x += hsp;

if(instance_exists(obj_player)){

    //if player under of the platform or clicks down
    if ((round( obj_player.y + (obj_player.sprite_height/2)) > y) || obj_player.key_down){
         mask_index=-1; //disable collision
    }else{
         mask_index=spr_platform;
         
         //si está justo encima
         if ( place_meeting(x,y-1,obj_player)){
            obj_player.hsp_carry = hsp;
         }
         
         
         
    }
    
  
}



