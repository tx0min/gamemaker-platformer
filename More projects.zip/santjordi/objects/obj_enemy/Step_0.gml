if(global.pause) exit;



hsp = dir * movespeed;
vsp += grav;


//Horizontal collision
if(place_meeting(x+hsp,y,obj_wall)){
    while(!place_meeting(x+sign(hsp),y,obj_wall)){ 
        //sign devuelve 1 o -1
        x+=sign(hsp);
    }
    hsp=0;
    dir*=-1;
}
x += hsp;

//Vertical collision
if(place_meeting(x,y+vsp,obj_wall)){
    while(!place_meeting(x,y+sign(vsp),obj_wall)){ 
        y+=sign(vsp);
    }
    vsp=0;
    
    if((fearofheights) && !position_meeting(x+(sprite_width/2)*dir, y+(sprite_height/2)+ maxheightfear, obj_wall)){
        dir *= -1;
    }
}
y += vsp;


//player collision
if(place_meeting(x,y,obj_player)){
   //si tiene el powerup mato al enemigo
    if(obj_player.invencible){
        global.points+=25;
        instance_destroy();
    }else{
       //si viene de arriba lo mata
       
       if( obj_player.y  < y - obj_player.sprite_height/2 ){
            global.points+=25;
            with(obj_player) vsp = -jumpspeed;
            instance_destroy();
        }else{    
            //muere el jugador
             scr_death();
        }
    }
}



