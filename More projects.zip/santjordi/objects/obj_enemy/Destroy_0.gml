action_sound(snd_kill, 0);
