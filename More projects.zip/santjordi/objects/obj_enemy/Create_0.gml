//Initialize variables

dir=-1;

movespeed=3;
grav=0.2;
hsp=0;
vsp=0;

fearofheights = 0;

maxheightfear=sprite_height/3;


