// Fragment
uniform vec4 f_colour;

varying vec2 v_vTexcoord;
varying vec4 v_vColour;

void main()
{
    vec4 col = texture2D( gm_BaseTexture, v_vTexcoord );
    col.rgb = mix(col.rgb, f_colour.rgb, f_colour.a);
    gl_FragColor = v_vColour * col;
}
