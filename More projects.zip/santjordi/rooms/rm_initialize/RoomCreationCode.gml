global.points=0;

global.checkpoint=noone;
global.checkpointx=0;
global.checkpointy=0;

room_goto_next();